# Virtual Location Pro 4.0

Android 虚拟定位/开发测试工具，使用 Android Mock Location API。

## 4.0 新功能
- 真实可交互地图
- 点击地图设置模拟位置
- 长按/右键地图设置路线目标
- “当前GPS”读取系统最近一次定位
- 当前模拟位置地图标记
- 路线轨迹线与移动动画
- 开始/停止按钮
- 速度控制
- 地址/城市搜索
- 快捷城市与收藏
- 深色模式

## 使用
Android 开发者选项 → 选择模拟位置信息应用 → Virtual Location Pro。

地图图层来自 OpenStreetMap，搜索使用 Nominatim；需要网络。

本项目用于开发、测试和演示，不提供绕过第三方 App 反模拟定位检测、隐藏 Mock Location 状态或其他完整性校验的功能。
