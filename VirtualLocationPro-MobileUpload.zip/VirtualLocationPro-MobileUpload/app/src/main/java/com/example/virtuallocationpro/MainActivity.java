package com.example.virtuallocationpro;

import android.app.*;
import android.os.*;
import android.location.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
  LocationManager lm; EditText lat,lon,speed,search; TextView status,coords; LinearLayout root,favorites;
  Handler handler=new Handler(Looper.getMainLooper()); WebView map; boolean running=false,dark=false;
  final String PROVIDER="VirtualLocationPro"; double routeLat,routeLon,targetLat,targetLon,currentLat=34.052235,currentLon=-118.243683;
  boolean hasCurrent=false;
  String[][] cities={{"Los Angeles","34.052235","-118.243683"},{"San Francisco","37.774929","-122.419418"},{"New York","40.712776","-74.005974"},{"Tokyo","35.676200","139.650000"},{"Beijing","39.904200","116.407400"},{"Shanghai","31.230400","121.473700"}};

  @Override public void onCreate(Bundle b){super.onCreate(b);lm=(LocationManager)getSystemService(LOCATION_SERVICE);buildUI();if(checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},101);}
  TextView tv(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setPadding(0,8,0,8);return t;}
  Button btn(String s){Button b=new Button(this);b.setText(s);return b;}

  void buildUI(){
    ScrollView scroll=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(20,24,20,24);scroll.addView(root);
    TextView title=tv("📍 Virtual Location Pro 3.0",25);title.setGravity(Gravity.CENTER);root.addView(title);
    status=tv("状态：等待设置模拟位置信息应用",15);root.addView(status);coords=tv("当前位置：--",14);root.addView(coords);

    root.addView(tv("地图选点",18));
    map=new WebView(this);map.getSettings().setJavaScriptEnabled(true);map.getSettings().setDomStorageEnabled(true);map.setWebViewClient(new WebViewClient());map.addJavascriptInterface(new Object(){@JavascriptInterface public void setPickedLocation(double a,double o){runOnUiThread(()->{lat.setText(String.format(Locale.US,"%.6f",a));lon.setText(String.format(Locale.US,"%.6f",o));coords.setText(String.format(Locale.US,"地图选中：%.6f, %.6f",a,o));});}
      @JavascriptInterface public void setTargetLocation(double a,double o){runOnUiThread(()->{lat.setText(String.format(Locale.US,"%.6f",a));lon.setText(String.format(Locale.US,"%.6f",o));coords.setText(String.format(Locale.US,"路线目标：%.6f, %.6f",a,o));status.setText("已设置路线目标；点击“🚗 从当前模拟位置移动到目标”开始");});}},"Android");
    map.loadUrl("file:///android_asset/map.html");root.addView(map,new LinearLayout.LayoutParams(-1,600));

    LinearLayout sr=new LinearLayout(this);search=new EditText(this);search.setHint("搜索地址/城市，例如 Hollywood, Los Angeles");Button sb=btn("搜索");sr.addView(search,new LinearLayout.LayoutParams(0,-2,1));sr.addView(sb,new LinearLayout.LayoutParams(-2,-2));root.addView(sr);
    sb.setOnClickListener(v->searchAddress());

    LinearLayout row=new LinearLayout(this);lat=new EditText(this);lon=new EditText(this);lat.setHint("纬度");lon.setHint("经度");lat.setInputType(8194);lon.setInputType(8194);row.addView(lat,new LinearLayout.LayoutParams(0,-2,1));row.addView(lon,new LinearLayout.LayoutParams(0,-2,1));root.addView(row);
    speed=new EditText(this);speed.setHint("路线速度 m/s（默认 5）");speed.setInputType(2);root.addView(speed);
    LinearLayout controls=new LinearLayout(this);Button start=btn("▶ 开始定位"),stop=btn("■ 停止"),here=btn("◎ 当前GPS"),theme=btn("🌙");for(Button x:new Button[]{start,stop,here,theme})controls.addView(x,new LinearLayout.LayoutParams(0,-2,1));root.addView(controls);
    root.addView(tv("快捷城市",18));LinearLayout cityBox=new LinearLayout(this);cityBox.setOrientation(LinearLayout.VERTICAL);for(String[] c:cities){Button x=btn(c[0]);x.setOnClickListener(v->{setCoords(c[1],c[2],10);});cityBox.addView(x);}root.addView(cityBox);
    root.addView(tv("路线模拟",18));Button route=btn("🚗 从当前模拟位置移动到目标");root.addView(route);
    root.addView(tv("收藏地点",18));favorites=new LinearLayout(this);favorites.setOrientation(LinearLayout.VERTICAL);root.addView(favorites);loadFavorites();
    root.addView(tv("使用前：Android 开发者选项 → 选择模拟位置信息应用 → Virtual Location Pro。地图使用 OpenStreetMap/Leaflet，需要网络。",13));setContentView(scroll);
    start.setOnClickListener(v->sendInput());stop.setOnClickListener(v->stop());here.setOnClickListener(v->useCurrentLocation());save.setOnClickListener(v->saveFavorite());route.setOnClickListener(v->startRoute());theme.setOnClickListener(v->{dark=!dark;applyTheme();});applyTheme();
  }
  void setCoords(String a,String o,int zoom){lat.setText(a);lon.setText(o);try{map.evaluateJavascript("setLocation("+a+","+o+","+zoom+")",null);}catch(Exception ignored){}}
  double d(EditText e){return Double.parseDouble(e.getText().toString().trim());} boolean valid(double a,double o){return a>=-90&&a<=90&&o>=-180&&o<=180;}
  void ensureProvider(){if(!lm.getAllProviders().contains(PROVIDER))lm.addTestProvider(PROVIDER,false,false,false,false,true,true,true,Criteria.POWER_LOW,Criteria.ACCURACY_FINE);lm.setTestProviderEnabled(PROVIDER,true);}
  void mock(double a,double o){try{currentLat=a;currentLon=o;hasCurrent=true;ensureProvider();Location l=new Location(PROVIDER);l.setLatitude(a);l.setLongitude(o);l.setAccuracy(3f);l.setTime(System.currentTimeMillis());l.setElapsedRealtimeNanos(SystemClock.elapsedRealtimeNanos());lm.setTestProviderLocation(PROVIDER,l);coords.setText(String.format(Locale.US,"模拟位置：%.6f, %.6f",a,o));try{map.evaluateJavascript("setLocation("+a+","+o+",14)",null);}catch(Exception ignored){}status.setText("状态：模拟位置已发送");}catch(SecurityException e){status.setText("请在开发者选项中选择本 App 作为模拟位置信息应用");}catch(Exception e){status.setText("系统拒绝模拟位置："+e.getClass().getSimpleName());}}
  void sendInput(){try{double a=d(lat),o=d(lon);if(!valid(a,o))throw new Exception();running=false;mock(a,o);}catch(Exception e){status.setText("请输入有效经纬度");}}
  void startRoute(){try{targetLat=d(lat);targetLon=d(lon);if(!valid(targetLat,targetLon))throw new Exception();if(!hasCurrent){currentLat=targetLat-0.02;currentLon=targetLon-0.02;}routeLat=currentLat;routeLon=currentLon;running=true;status.setText("状态：路线模拟中");try{map.evaluateJavascript("startRoute("+routeLat+","+routeLon+","+targetLat+","+targetLon+")",null);}catch(Exception ignored){}handler.post(routeTick);}catch(Exception e){status.setText("请先输入有效目标坐标");}}
  Runnable routeTick=new Runnable(){public void run(){if(!running)return;double s=5;try{if(!speed.getText().toString().trim().isEmpty())s=Math.max(1,Math.min(100,Double.parseDouble(speed.getText().toString())));}catch(Exception ignored){}routeLat+=(targetLat-routeLat)*0.08;routeLon+=(targetLon-routeLon)*0.08;mock(routeLat,routeLon);try{map.evaluateJavascript("moveRoute("+routeLat+","+routeLon+")",null);}catch(Exception ignored){}if(Math.abs(targetLat-routeLat)<.00001&&Math.abs(targetLon-routeLon)<.00001){mock(targetLat,targetLon);running=false;status.setText("状态：已到达目标位置");}else handler.postDelayed(this,Math.max(100,(long)(1000/(s/5))));}};
  void stop(){running=false;handler.removeCallbacks(routeTick);try{lm.setTestProviderEnabled(PROVIDER,false);lm.removeTestProvider(PROVIDER);}catch(Exception ignored){}try{map.evaluateJavascript("stopRoute()",null);}catch(Exception ignored){}status.setText("状态：已停止");}
  void useCurrentLocation(){
    try{
      Location best=null;
      for(String p:new String[]{LocationManager.GPS_PROVIDER,LocationManager.NETWORK_PROVIDER}){
        try{Location x=lm.getLastKnownLocation(p);if(x!=null&&(best==null||x.getTime()>best.getTime()))best=x;}catch(SecurityException ignored){}
      }
      if(best==null){status.setText("暂时没有可用的系统定位记录，请开启定位后重试");return;}
      double a=best.getLatitude(),o=best.getLongitude();
      setCoords(String.format(Locale.US,"%.6f",a),String.format(Locale.US,"%.6f",o),15);
      hasCurrent=true;currentLat=a;currentLon=o;status.setText("已读取系统最近定位："+String.format(Locale.US,"%.6f, %.6f",a,o));
    }catch(Exception e){status.setText("读取当前位置失败");}
  }
  void saveFavorite(){try{String key=String.format(Locale.US,"%.6f,%.6f",d(lat),d(lon));getSharedPreferences("fav",0).edit().putString(key,key).apply();loadFavorites();status.setText("已收藏："+key);}catch(Exception e){status.setText("无法收藏：请先输入坐标");}}
  void loadFavorites(){if(favorites==null)return;favorites.removeAllViews();Map<String,?> all=getSharedPreferences("fav",0).getAll();if(all.isEmpty()){favorites.addView(tv("暂无收藏",14));return;}for(String k:all.keySet()){Button b=btn("★ "+k);b.setOnClickListener(v->{String[] p=k.split(",");setCoords(p[0],p[1],14);});favorites.addView(b);}}
  void searchAddress(){String q=search.getText().toString().trim();if(q.isEmpty()){status.setText("请输入地址或城市");return;}status.setText("正在搜索："+q);new Thread(()->{try{String url="https://nominatim.openstreetmap.org/search?format=json&limit=1&q="+URLEncoder.encode(q,"UTF-8");HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setRequestProperty("User-Agent","VirtualLocationPro/3.0");BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream()));StringBuilder sb=new StringBuilder();String line;while((line=r.readLine())!=null)sb.append(line);JSONArray a=new JSONArray(sb.toString());if(a.length()==0)throw new Exception("未找到");JSONObject o=a.getJSONObject(0);double la=o.getDouble("lat"),lo=o.getDouble("lon");runOnUiThread(()->{setCoords(String.format(Locale.US,"%.6f",la),String.format(Locale.US,"%.6f",lo),15);status.setText("找到："+o.optString("display_name"));});}catch(Exception e){runOnUiThread(()->status.setText("搜索失败："+e.getMessage()));}}).start();}
  void applyTheme(){int bg=dark?Color.rgb(25,25,25):Color.WHITE,fg=dark?Color.WHITE:Color.rgb(30,30,30);root.setBackgroundColor(bg);for(int i=0;i<root.getChildCount();i++)tint(root.getChildAt(i),fg,bg);}
  void tint(View v,int fg,int bg){if(v instanceof TextView)((TextView)v).setTextColor(fg);if(v instanceof ViewGroup){ViewGroup g=(ViewGroup)v;for(int i=0;i<g.getChildCount();i++)tint(g.getChildAt(i),fg,bg);}}
  @Override protected void onDestroy(){stop();if(map!=null)map.destroy();super.onDestroy();}
}
