# 不安装 Android Studio，在线生成 APK

这个项目已经加入 GitHub Actions 自动构建配置。你不需要在电脑安装 Android Studio 或 Gradle。

## 最简单的做法

1. 在 GitHub 新建一个空的仓库，例如 `VirtualLocationPro`。
2. 把本项目里的全部文件上传到仓库（保持 `.github/workflows/build-apk.yml` 路径不变）。
3. 打开仓库的 **Actions** → **Build Virtual Location APK** → **Run workflow**。
4. 构建完成后，进入这次运行记录，在 **Artifacts** 下载 `VirtualLocationPro-debug-apk`。
5. 解压后得到 `app-debug.apk`，传到 Android 手机安装。

如果第一次运行失败，重新运行一次通常即可；若日志提示 SDK/构建工具问题，可把错误日志发给我，我会修改工作流。

## 手机端使用

安装后需要在 Android 的开发者选项中启用模拟位置信息，并选择本 App 作为“模拟位置信息应用”。这是 Android 官方测试机制，不包含绕过第三方 App 的反模拟定位检测功能。
